from pyrogram import Client, filters

from core.player import set_volume


@Client.on_message(filters.text & filters.regex(r"^حماصه الصوت"))
async def volume_command(client, message):
    chat_id = message.chat.id

    args = message.text.split()

    if len(args) != 3:
        await message.reply_text(
            "مثال:\nحماصه الصوت 100"
        )
        return

    try:
        volume = int(args[2])
    except ValueError:
        await message.reply_text(
            "❌ يجب أن تكون القيمة رقمًا."
        )
        return

    volume = max(1, min(volume, 200))

    await set_volume(chat_id, volume)

    await message.reply_text(
        f"🔊 تم ضبط الصوت إلى {volume}%"
    )