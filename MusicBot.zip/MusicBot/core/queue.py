from typing import Dict, List, Optional


class QueueManager:
    def init(self):
        self.queues: Dict[int, List[dict]] = {}
        self.current: Dict[int, Optional[dict]] = {}

    def create_queue(self, chat_id: int):
        if chat_id not in self.queues:
            self.queues[chat_id] = []

    def add(self, chat_id: int, song: dict):
        self.create_queue(chat_id)
        self.queues[chat_id].append(song)

    def get(self, chat_id: int):
        self.create_queue(chat_id)
        return self.queues[chat_id]

    def next(self, chat_id: int):
        self.create_queue(chat_id)

        if not self.queues[chat_id]:
            self.current[chat_id] = None
            return None

        song = self.queues[chat_id].pop(0)
        self.current[chat_id] = song

        return song

    def current_song(self, chat_id: int):
        return self.current.get(chat_id)

    def clear(self, chat_id: int):
        self.queues[chat_id] = []
        self.current[chat_id] = None

    def is_empty(self, chat_id: int):
        self.create_queue(chat_id)
        return len(self.queues[chat_id]) == 0


queue = QueueManager()


async def add_to_queue(chat_id: int, song: dict):
    queue.add(chat_id, song)


def get_queue(chat_id: int):
    return queue.get(chat_id)


def get_next_song(chat_id: int):
    return queue.next(chat_id)


def get_current_song(chat_id: int):
    return queue.current_song(chat_id)


def clear_queue(chat_id: int):
    queue.clear(chat_id)


def queue_is_empty(chat_id: int):
    return queue.is_empty(chat_id)