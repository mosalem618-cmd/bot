from core.queue import (
    get_next_song,
    get_current_song,
    clear_queue,
)

from core.call import change_stream


players = {}


async def play_audio(chat_id: int):
    song = get_next_song(chat_id)

    if not song:
        return False

    await change_stream(
        chat_id,
        song["stream_url"]
    )

    players[chat_id] = {
        "status": "playing",
        "song": song,
        "volume": 100,
    }

    return True


async def stop_player(chat_id: int):
    if chat_id not in players:
        return False

    clear_queue(chat_id)

    players.pop(chat_id)

    return True


async def pause_player(chat_id: int):
    if chat_id not in players:
        return False

    players[chat_id]["status"] = "paused"

    return True


async def resume_player(chat_id: int):
    if chat_id not in players:
        return False

    players[chat_id]["status"] = "playing"

    return True


async def skip_player(chat_id: int):
    if chat_id not in players:
        return False

    return await play_audio(chat_id)


async def set_volume(chat_id: int, volume: int):
    if chat_id not in players:
        return False

    players[chat_id]["volume"] = volume

    return True


def get_current_song(chat_id: int):
    if chat_id not in players:
        return None

    return players[chat_id]["song"]