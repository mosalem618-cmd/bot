from pyrogram import Client, filters

from config import BOT_NAME


@Client.on_message(filters.command("start"))
async def start_command(client, message):
    await message.reply_text(
        f"""
🎵 أهلاً بك في {BOT_NAME}

أنا بوت موسيقى احترافي لتشغيل الأغاني داخل المكالمات الصوتية.

📌 الأوامر الأساسية:

• حماصه شغل <اسم الأغنية>
• حماصه ايقاف
• حماصه تخطي
• حماصه وقف مؤقت
• حماصه كمل
• حماصه خروج
• حماصه الحالي
• حماصه القائمة

استخدم /help لمعرفة جميع الأوامر.
"""
    )