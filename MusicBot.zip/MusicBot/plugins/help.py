from pyrogram import Client, filters

from config import BOT_NAME


@Client.on_message(filters.command("help"))
async def help_command(client, message):
    await message.reply_text(
        f"""
📖 {BOT_NAME}

━━━━━━━━━━━━━━

🎵 أوامر التشغيل

• حماصه شغل <اسم الأغنية>
تشغيل أغنية داخل المكالمة.

• حماصه ايقاف
إيقاف التشغيل.

• حماصه وقف مؤقت
إيقاف الأغنية مؤقتًا.

• حماصه كمل
استكمال التشغيل.

• حماصه تخطي
تشغيل الأغنية التالية.

• حماصه خروج
مغادرة المكالمة الصوتية.

━━━━━━━━━━━━━━

📋 أوامر إضافية

• حماصه الحالي
عرض الأغنية الحالية.

• حماصه القائمة
عرض قائمة الانتظار.

• حماصه الصوت
تغيير مستوى الصوت.

━━━━━━━━━━━━━━

🎵 Hamasa Music Bot v1.0
"""
    )