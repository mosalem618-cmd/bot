from pyrogram import Client, filters


@Client.on_message(filters.text & filters.regex(r"^حماصه الاعدادات$"))
async def settings_command(client, message):
    await message.reply_text(
        """
⚙️ إعدادات Hamasa Music Bot

• مستوى الصوت
• قائمة الانتظار
• جودة التشغيل

سيتم إضافة المزيد من الإعدادات في الإصدارات القادمة.
"""
    )