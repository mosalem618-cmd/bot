from pyrogram import Client, filters

from core.player import get_current_song


@Client.on_message(filters.text & filters.regex(r"^حماصه الحالي$"))
async def nowplaying_command(client, message):
    chat_id = message.chat.id

    song = get_current_song(chat_id)

    if not song:
        await message.reply_text(
            "❌ لا توجد أغنية قيد التشغيل."
        )
        return

    await message.reply_text(
        f"""
🎵 الأغنية الحالية

الاسم:
{song['title']}

المدة:
{song['duration']}
"""
    )