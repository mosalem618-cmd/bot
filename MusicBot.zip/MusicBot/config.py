from os import getenv
from dotenv import load_dotenv

# تحميل ملف .env
load_dotenv()

# Telegram API
API_ID = int(getenv("API_ID", "0"))
API_HASH = getenv("API_HASH", "")

# Bot
BOT_TOKEN = getenv("BOT_TOKEN", "")
BOT_NAME = getenv("BOT_NAME", "Hamasa Music Bot")
BOT_USERNAME = getenv("BOT_USERNAME", "")

# Assistant
STRING_SESSION = getenv("STRING_SESSION", "")

# Developer
OWNER_ID = int(getenv("OWNER_ID", "0"))

# Logs
LOG_GROUP_ID = getenv("LOG_GROUP_ID", "")

# Audio
DEFAULT_VOLUME = int(getenv("DEFAULT_VOLUME", "100"))

# Paths
DOWNLOAD_PATH = getenv("DOWNLOAD_PATH", "downloads/")
CACHE_PATH = getenv("CACHE_PATH", "cache/")
LOG_PATH = getenv("LOG_PATH", "logs/")