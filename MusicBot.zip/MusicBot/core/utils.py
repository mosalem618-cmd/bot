import os
import uuid

from config import DOWNLOAD_PATH


os.makedirs(DOWNLOAD_PATH, exist_ok=True)


def generate_filename(extension: str = ".mp3") -> str:
    return os.path.join(
        DOWNLOAD_PATH,
        f"{uuid.uuid4().hex}{extension}"
    )


def format_duration(seconds: int) -> str:
    minutes = seconds // 60
    seconds = seconds % 60
    return f"{minutes}:{seconds:02d}"