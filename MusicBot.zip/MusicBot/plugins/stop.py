from pyrogram import Client, filters

from core.player import stop_player


@Client.on_message(filters.text & filters.regex(r"^حماصه ايقاف$"))
async def stop_command(client, message):
    chat_id = message.chat.id

    result = await stop_player(chat_id)

    if result:
        await message.reply_text(
            "⏹️ تم إيقاف تشغيل الموسيقى."
        )
    else:
        await message.reply_text(
            "❌ لا يوجد أي تشغيل حالي."
        )