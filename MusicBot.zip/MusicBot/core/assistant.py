from core.client import assistant
from core.logger import info, error


async def start_assistant():
    try:
        await assistant.start()

        me = await assistant.get_me()

        info(
            f"Assistant Started Successfully: "
            f"{me.first_name} (@{me.username})"
        )

    except Exception as e:
        error(f"Assistant Start Error: {e}")
        raise e


async def stop_assistant():
    try:
        await assistant.stop()

        info("Assistant Stopped Successfully.")

    except Exception as e:
        error(f"Assistant Stop Error: {e}")