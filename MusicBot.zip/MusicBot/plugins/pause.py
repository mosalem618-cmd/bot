from pyrogram import Client, filters

from core.player import pause_player


@Client.on_message(filters.text & filters.regex(r"^حماصه وقف مؤقت$"))
async def pause_command(client, message):
    chat_id = message.chat.id

    result = await pause_player(chat_id)

    if result:
        await message.reply_text(
            "⏸️ تم إيقاف التشغيل مؤقتًا."
        )
    else:
        await message.reply_text(
            "❌ لا يوجد تشغيل لإيقافه."
        )