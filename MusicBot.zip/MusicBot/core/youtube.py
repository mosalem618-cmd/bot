from youtubesearchpython.future import VideosSearch


async def search_youtube(query: str):
    try:
        search = VideosSearch(query, limit=1)

        results = await search.next()

        if not results["result"]:
            return None

        video = results["result"][0]

        return {
            "title": video["title"],
            "video_id": video["id"],
            "url": f"https://www.youtube.com/watch?v={video['id']}",
            "duration": video["duration"],
            "thumbnail": video["thumbnails"][0]["url"],
            "channel": video["channel"]["name"],
        }

    except Exception as error:
        print(f"YouTube Search Error: {error}")
        return None