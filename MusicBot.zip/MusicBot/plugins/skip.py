from pyrogram import Client, filters

from core.player import skip_player


@Client.on_message(filters.text & filters.regex(r"^حماصه تخطي$"))
async def skip_command(client, message):
    chat_id = message.chat.id

    result = await skip_player(chat_id)

    if result:
        await message.reply_text(
            "⏭️ تم تخطي الأغنية الحالية."
        )
    else:
        await message.reply_text(
            "❌ لا توجد أغنية لتخطيها."
        )