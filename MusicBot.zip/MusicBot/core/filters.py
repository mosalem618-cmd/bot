from pyrogram import filters


music_filter = filters.text & filters.group


admin_filter = filters.group