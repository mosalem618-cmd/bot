from pyrogram import Client, filters

from core.player import resume_player


@Client.on_message(filters.text & filters.regex(r"^حماصه كمل$"))
async def resume_command(client, message):
    chat_id = message.chat.id

    result = await resume_player(chat_id)

    if result:
        await message.reply_text(
            "▶️ تم استكمال التشغيل."
        )
    else:
        await message.reply_text(
            "❌ لا يوجد تشغيل متوقف."
        )