from core.youtube import search_youtube
from core.downloader import download_audio


async def search_song(query: str):
    video = await search_youtube(query)

    if not video:
        return None

    audio = await download_audio(video["url"])

    if not audio:
        return None

    return {
        "title": audio["title"],
        "duration": audio["duration"],
        "thumbnail": audio["thumbnail"],
        "stream_url": audio["stream_url"],
        "url": audio["webpage_url"],
    }