from pyrogram.types import Message

from pytgcalls import PyTgCalls
from pytgcalls.types.input_stream import AudioPiped

from core.assistant import assistant
from core.logger import info


call = PyTgCalls(assistant)


async def start_call():
    await call.start()

    info("Voice Client Started Successfully.")


async def join_voice_chat(chat_id: int):
    try:
        await call.join_group_call(
            chat_id,
            AudioPiped("blank.raw")
        )

        info(f"Joined Voice Chat: {chat_id}")

        return True

    except Exception as error:
        info(f"Join Voice Chat Error: {error}")

        return False


async def leave_voice_chat(chat_id: int):
    try:
        await call.leave_group_call(chat_id)

        info(f"Left Voice Chat: {chat_id}")

        return True

    except Exception as error:
        info(f"Leave Voice Chat Error: {error}")

        return False


async def change_stream(chat_id: int, file_path: str):
    try:
        await call.change_stream(
            chat_id,
            AudioPiped(file_path)
        )

        info(f"Stream Changed: {chat_id}")

        return True

    except Exception as error:
        info(f"Change Stream Error: {error}")

        return False