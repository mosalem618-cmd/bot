import asyncio

from core.client import bot
from core.assistant import start_assistant
from core.call import start_call
from core.logger import info


async def main():
    info("Starting Hamasa Music Bot...")

    await start_assistant()
    await start_call()

    await bot.start()

    me = await bot.get_me()

    info(f"Bot Started Successfully: @{me.username}")

    await asyncio.Event().wait()


if name == "main":
    asyncio.run(main())