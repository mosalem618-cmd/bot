from pyrogram.types import Message


async def is_admin(message: Message) -> bool:
    member = await message.chat.get_member(
        message.from_user.id
    )

    return member.privileges is not None