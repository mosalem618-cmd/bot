import logging
import os

from config import LOG_PATH


os.makedirs(LOG_PATH, exist_ok=True)


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    handlers=[
        logging.FileHandler(f"{LOG_PATH}/musicbot.log"),
        logging.StreamHandler()
    ]
)


logger = logging.getLogger("HamasaMusicBot")


def info(message: str):
    logger.info(message)


def warning(message: str):
    logger.warning(message)


def error(message: str):
    logger.error(message)


def critical(message: str):
    logger.critical(message)