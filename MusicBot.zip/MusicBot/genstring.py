from pyrogram import Client
from pyrogram.errors import SessionPasswordNeeded

from config import API_ID, API_HASH


print("=" * 50)
print("🎵 Hamasa Music Bot - String Session Generator")
print("=" * 50)


with Client(
    "HamasaString",
    api_id=API_ID,
    api_hash=API_HASH,
    in_memory=True,
) as app:
    session = app.export_session_string()

print("\n✅ STRING_SESSION\n")
print(session)
print("\nانسخ القيمة وضعها داخل ملف .env")