from pyrogram import Client, filters

from core.search import search_song
from core.queue import add_to_queue
from core.call import join_voice_chat
from core.player import play_audio


@Client.on_message(filters.text & filters.regex(r"^حماصه شغل"))
async def play_command(client, message):
    chat_id = message.chat.id

    text = message.text.replace("حماصه شغل", "").strip()

    if not text:
        await message.reply_text(
            "❌ اكتب اسم الأغنية بعد الأمر.\n\n"
            "مثال:\n"
            "حماصه شغل تملي معاك"
        )
        return

    waiting = await message.reply_text(
        f"🔍 جاري البحث عن:\n\n🎵 {text}"
    )

    song = await search_song(text)

    if not song:
        await waiting.edit_text(
            "❌ لم يتم العثور على أي نتائج."
        )
        return

    await add_to_queue(chat_id, song)

    await join_voice_chat(chat_id)

    await play_audio(chat_id)

    await waiting.edit_text(
        f"🎶 تم إضافة الأغنية إلى قائمة التشغيل.\n\n"
        f"🎵 {song['title']}"
    )