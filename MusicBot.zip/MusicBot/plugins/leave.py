from pyrogram import Client, filters

from core.call import leave_voice_chat


@Client.on_message(filters.text & filters.regex(r"^حماصه خروج$"))
async def leave_command(client, message):
    chat_id = message.chat.id

    result = await leave_voice_chat(chat_id)

    if result:
        await message.reply_text(
            "👋 تمت مغادرة المكالمة الصوتية."
        )
    else:
        await message.reply_text(
            "❌ البوت ليس داخل أي مكالمة صوتية."
        )