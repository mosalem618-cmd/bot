from pyrogram import Client, filters

from core.queue import get_queue


@Client.on_message(filters.text & filters.regex(r"^حماصه القائمة$"))
async def queue_command(client, message):
    chat_id = message.chat.id

    queue = get_queue(chat_id)

    if not queue:
        await message.reply_text(
            "📭 قائمة الانتظار فارغة."
        )
        return

    text = "📋 قائمة الانتظار:\n\n"

    for index, song in enumerate(queue, start=1):
        text += f"{index}. {song['title']}\n"

    await message.reply_text(text)